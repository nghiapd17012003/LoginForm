
using System.Data;
using System.Data.SqlClient;
namespace LoginForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-M969PBHG\SQLEXPRESS;Initial Catalog=loginIn4;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select * from Table_1 where username='"+txtUsername.Text+"' and password ='"+ txtPassword.Text+ "'", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows.Count > 0)//if username match password
            {
                MessageBox.Show("Login success!");
            }

            else 
            {
                MessageBox.Show("Wrong username or password! Please try again!");
            }
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-M969PBHG\SQLEXPRESS;Initial Catalog=loginIn4;Integrated Security=True");
            //compare Username textbox to username colunm and Password textbox to password colunm in the sql data table
            SqlCommand cmd = new SqlCommand("select * from Table_1 where username='" + txtUsername.Text + "' and password ='" + txtPassword.Text + "'", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows.Count > 0)//if username + password match
            {               
                SqlCommand changePassword_cmd = new SqlCommand("UPDATE [dbo].[Table_1] SET [password] = '"+NewPassword.Text+"'WHERE username = '"+ txtUsername.Text + "' ", con);
                con.Open();
                changePassword_cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Password changed successfully!");
            }

            else
            {
                MessageBox.Show("Wrong username or password! Please try again!");
            }
        }
    }
}